<h1 class="text-center">Page d'accueil</h1>
<main>
    <h2 class="text-center">Quelle super page, t'as fait ça tout seul?</h2>
    <h6 class="text-center">(sans blague...)</h6>
</main>