<section class="mt-4 container">
    <h1 class="text-center">Inscription</h1>
    <?= $form; ?>
</section>