<section class="mt-4 container">
    <h1 class="text-center">Création d'un article</h1>
    <?= $form; ?>
</section>