<section class="mt-4">
    <h1 class="text-center">Modification d'un user</h1>
    <?= $form; ?>
</section>