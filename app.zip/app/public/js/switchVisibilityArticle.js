const inputs = document.querySelectorAll('input[switch-article-id]');

console.error(inputs);